from blob_detection import detect
from utils import triangulate, navigate, draw_vtm, draw_pts, draw_bot, draw_rts, display_msg, remove_vtm,draw_pts2, draw_bot2, draw_rts2,display_msg2,navigate2
import numpy as np
import cv2
import time
import requests
import datetime
from multiprocessing.dummy import Pool

pool = Pool(10)
                


url1 = "http://192.168.50.4"
url2 = "http://192.168.50.4"
url3 = "http://192.168.50.6"
url4 = "http://192.168.50.7"

font = cv2.FONT_HERSHEY_SCRIPT_COMPLEX


print("Starting camera...")
robot=1

cap = cv2.VideoCapture(1,cv2.CAP_DSHOW)
frame_rate = 5

# Variable to store the previous time of analysed frame
prev = 0

# Define the codec and create VideoWriter object.The output is stored in 'output.avi' file.
out = cv2.VideoWriter('output.avi',cv2.VideoWriter_fourcc(*'XVID'), 30.0, (640,480))

# Load the mask for calibration and removing unwanted area from frames
mask = cv2.imread('images/mask2.png', 0)
calibrate = cv2.imread('images/calibrate.png', 0)
rts2=[]
angle2=0
dist2=0


starting1 = True
restarting1 = False
finished1 = False

starting2 = False
restarting2 = False
finished2 = False

starting3 = False
restarting3 = False
finished3 = False

starting4 = False
restarting4 = False
finished4 = False

def ini():
        seq = 0

        # Variables to store the location and orientation of robot
        pos = np.array([60, 450])
        dirn = np.array([0, -10])

        marker = []


# Sequence of markers for robot movement
start3 = [np.array([100, 35]),np.array([100, 420])]
restart3 = [np.array([100, 38]),np.array([510, 35]),np.array([450, 35])]

start4 = [np.array([150, 90]),np.array([150, 430])]
restart4 = [np.array([150, 85]),np.array([510, 85]),np.array([450, 85])]


start1 = [np.array([480, 80]),np.array([480, 410])]
restart1 = [np.array([480, 80]),np.array([80, 80])]

start2 = [np.array([550, 20]),np.array([550, 430])]
restart2 = [np.array([550, 20]),np.array([20, 20])]

seq = 0

# Variables to store the location and orientation of robot
pos = np.array([60, 450])
dirn = np.array([0, -10])

# Variables to store the location and orientation of robot
pos2 = np.array([60, 450])
dirn2 = np.array([0, -10])

marker = []
marker2 = []
camera=1

present = datetime.datetime.now()
# Main loop
while True:
	if (camera==1):
		time_elapsed = time.time() - prev
		ret, frame = cap.read()
		dt = datetime.datetime.now()
		timer=dt-present
		fame=cv2.putText(frame, str(timer),(350, 350),font, 1,(0, 0, 0),2, cv2.LINE_8)
		
		

		if time_elapsed > 1./frame_rate and not finished1 and robot==1:
	                
			prev = time.time()
			#Threshold of magenta in HSV space 
			lower_magenta = np.array([150, 20, 100])
			upper_magenta = np.array([180,255,255])
			#lower_magenta = np.array([105, 75, 65])
			#upper_magenta = np.array([130,255,255])
			
			
			
			pts = detect(frame, mask, lower_magenta, upper_magenta)
			
			# Determine whether the robot is found
			if len(pts) >= 3:
				pos, dirn = triangulate(pts)

			
			
	                
			
			# Initiate the starting sequence

			if starting1:
				marker = start1
				rts, angle, dist = navigate(pos, dirn, start1[seq:seq+1])
				if dist < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(start1):
						seq = 0
						dist = 0
						starting1 = False
						r = requests.get(url1 + "/grab")
						print("Robot-1 Reached Destination")
						restarting1 = True

			# Initiate the restarting sequence
			#hello
			elif restarting1:
				marker = restart1
				rts, angle, dist = navigate(pos, dirn, restart1[seq:seq+1])
				if dist < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(restart1):
						seq = 0
						dist = 0
						r = requests.get(url1 + "/stop")
						restarting1 = False
						print("Robot-1 Reached Source")
						finished1 = True
						starting2=True
						ini()
						robot=2
						
						

			

			# Defining a params dict for the parameters to be sent to the API 
			parameters = {
				"angle": angle,
				"distance": dist
			} 
	  
			# Sending get request and saving the response as response object 
			pool.apply_async(requests.get, [url1 + "/move", parameters])

	        
		if not finished1:
			draw_pts(frame, marker)
			draw_bot(frame, pos, dirn)
			draw_rts(frame, pos, rts, angle, dist)

			display_msg(frame, "Angle={:.2f}, Distance={}".format(angle, dist), (0, 255, 0))


		if time_elapsed > 1./frame_rate and not finished2 and robot==2:
	                
	                
			prev = time.time()
			#Threshold of Blue in HSV space 
			lower_blue = np.array([105, 75, 70])
			upper_blue = np.array([130,255,255])
			pts = detect(frame, mask, lower_blue, upper_blue)
			
			# Determine whether the robot is found
			if len(pts) >= 3:
				pos2, dirn2 = triangulate(pts)

			
			
	                
			if starting2:
				marker2 = start2
				rts2, angle2, dist2 = navigate2(pos2, dirn2, start2[seq:seq+1])
				if dist2 < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(start2):
						seq = 0
						dist2 = 0
						starting2 = False
						r = requests.get(url2 + "/grab")
						print("Robot-2 Reached Destination")
						restarting2 = True

			# Initiate the restarting sequence
			elif restarting2:
				marker2 = restart2
				rts2, angle2, dist2 = navigate2(pos2, dirn2, restart2[seq:seq+1])
				if dist2 < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(restart2):
						seq = 0
						dist2 = 0
						r = requests.get(url2 + "/stop")
						restarting2 = False
						finished2 = True
						print("Robot-2 Reached Source")
						starting3 = True
						cap = cv2.VideoCapture(2)
						robot=3
						camera=2

			

			# Defining a params dict for the parameters to be sent to the API 
			parameters = {
				"angle": angle2,
				"distance": dist2
			} 
	  
			# Sending get request and saving the response as response object 
			pool.apply_async(requests.get, [url2 + "/move", parameters])

		

		if not finished2:
			draw_pts2(frame, marker2)
			draw_bot2(frame, pos2, dirn2)
			draw_rts2(frame, pos2, rts2, angle2, dist2)

			display_msg2(frame, "Angle={:.2f}, Distance={}".format(angle2, dist2), (255, 0, 0))
		
	



	if (camera==2):
		
		time_elapsed = time.time() - prev
		ret, frame = cap.read()
		dt = datetime.datetime.now()
		timer=dt-present
		fame=cv2.putText(frame, str(timer),(10, 30),font, 1,(210, 155, 155),2, cv2.LINE_8)
		#print("Camera 2 Turned on")
		#print(starting3,restarting3,finished3)
		#print(starting4,restarting4,finished4)
		starting3 = True
		

		if time_elapsed > 1./frame_rate and not finished3 and robot==3:
	                
			prev = time.time()
			#Threshold of magenta in HSV space 
			lower_magenta = np.array([150, 20, 100])
			upper_magenta = np.array([180,255,255])
			#lower_magenta = np.array([105, 75, 70])
			#upper_magenta = np.array([130,255,255])
			
			
			
			pts = detect(frame, mask, lower_magenta, upper_magenta)
			
			# Determine whether the robot is found
			if len(pts) >= 3:
				pos, dirn = triangulate(pts)

			
			
	                
			
			# Initiate the starting sequence

			if starting3:
				marker = start3
				rts, angle, dist = navigate(pos, dirn, start1[seq:seq+1])
				if dist < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(start3):
						seq = 0
						dist = 0
						starting3 = False
						r = requests.get(url3 + "/grab")
						print("Robot-3 Reached Destination")
						restarting3 = True

			# Initiate the restarting sequence
			#hello
			elif restarting3:
				marker = restart3
				rts, angle, dist = navigate(pos, dirn, restart1[seq:seq+1])
				if dist < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(restart3):
						seq = 0
						dist = 0
						r = requests.get(url1 + "/stop")
						restarting3 = False
						print("Robot-3 Reached Source")
						finished3 = True
						starting4=True
						ini()
						robot=4
						
						

			

			# Defining a params dict for the parameters to be sent to the API 
			parameters = {
				"angle": angle,
				"distance": dist
			} 
	  
			# Sending get request and saving the response as response object 
			pool.apply_async(requests.get, [url1 + "/move", parameters])

	        
		if not finished3:
			draw_pts(frame, marker)
			draw_bot(frame, pos, dirn)
			draw_rts(frame, pos, rts, angle, dist)

			display_msg(frame, "Angle={:.2f}, Distance={}".format(angle, dist), (0, 255, 0))


		if time_elapsed > 1./frame_rate and not finished4 and robot==2:
	                
	                
			prev = time.time()
			#Threshold of Blue in HSV space 
			lower_blue = np.array([105, 80, 70])
			upper_blue = np.array([130,255,255])
			pts = detect(frame, mask, lower_blue, upper_blue)
			
			# Determine whether the robot is found
			if len(pts) >= 3:
				pos2, dirn2 = triangulate(pts)

			
			
	                
			if starting4:
				marker2 = start4
				rts2, angle2, dist2 = navigate2(pos2, dirn2, start2[seq:seq+1])
				if dist2 < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(start4):
						seq = 0
						dist2 = 0
						starting4 = False
						r = requests.get(url2 + "/grab")
						print("Robot-4 Reached Destination")
						restarting4 = True

			# Initiate the restarting sequence
			elif restarting4:
				marker2 = restart4
				rts2, angle2, dist2 = navigate2(pos2, dirn2, restart2[seq:seq+1])
				if dist2 < 5 or cv2.waitKey(1) == ord(' '):
					seq += 1
					if seq == len(restart4):
						seq = 0
						dist2 = 0
						r = requests.get(url2 + "/stop")
						restarting4 = False
						finished4 = True
						print("Robot-4 Reached Source")
						

			

			# Defining a params dict for the parameters to be sent to the API 
			parameters = {
				"angle": angle2,
				"distance": dist2
			} 
	  
			# Sending get request and saving the response as response object 
			pool.apply_async(requests.get, [url4 + "/move", parameters])

		

		if not finished4:
			draw_pts2(frame, marker2)
			draw_bot2(frame, pos2, dirn2)
			draw_rts2(frame, pos2, rts2, angle2, dist2)

			display_msg2(frame, "Angle={:.2f}, Distance={}".format(angle2, dist2), (255, 0, 0))
        
	out.write(frame)
	cv2.imshow('frame', frame)
        
	c = cv2.waitKey(1)
	
        
        

	# Exit program when Esc key is pressed
	if c == ord('\x1b'):
		break
	

	

	

cap.release()


cv2.destroyAllWindows()
