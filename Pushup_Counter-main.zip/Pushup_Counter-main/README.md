# Pushup_Counter
Requires two libraries
1.mediapipe
2.Opencv
