# bus-track2k19
sudo nano /etc/dhcpcd.conf


interface eth0


static ip_address=172.7.70.71/16


static routers=172.7.0.254


static domain_name_servers=208.67.220.220
